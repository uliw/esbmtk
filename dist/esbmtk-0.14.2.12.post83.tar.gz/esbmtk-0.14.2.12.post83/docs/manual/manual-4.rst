

Seawater and Carbon Chemistry
-----------------------------

ESBMTK provides several classes that abstract the handling of basin geometry, seawater chemistry and air-sea gas exchange.  See ``Boudreau2010.py`` `https://github.com/uliw/ESBMTK-Examples <https://github.com/uliw/ESBMTK-Examples>`_ for an actual example how these classes are used to define a model.

Hypsography
~~~~~~~~~~~

For many modeling tasks, it is important to know a globally averaged hypsometric curve. ESBMTK will automatically create a suitable hypsography instance if a :py:class:`esbmtk.base_classes.Species()` or :py:class:`esbmtk.extended_classes.Reservoir()` instance is specified with the geometry keyword as in the following example where the first list item denotes the upper depth datum, the second list item, the lower depth datum, and the last list item denotes the fraction of the total ocean area if the upper boundary would be at sea level.

.. code:: ipython

    Reservoir(
        name="S_b",  # Name of reservoir group
        geometry=[-200, -800, 1],  # upper, lower, fraction
        concentration={M.DIC: "0 mmol/kg"},
    )
    print(f"M.S_b.area = {M.S_b.area:.2e}") # surface area at upper depth datum
    print(f"M.S_b.sed_area = {M.S_b.sed_area:.2e}") # surface between upper and lower datum
    print(f"M.S_b.volume = {M.S_b.volume:.2e}") # total volume

This will register 3 new instance variables, and also create a hypsometry instance at the model level that provides access to the following methods:

.. code:: ipython

    #return the ocean area at a given depth in m**2
    print(f"M.hyp.area(0) = {M.hyp.area(0):.2e}")

    # return the area between 2 depth datums in m**2
    print(f"M.hyp.area_dz(0, -200) = {M.hyp.area_dz(0, -200):.2e}")

    # return the volume between 2 depth datums in m**3
    print(f"M.hyp.volume(0,-200) = {M.hyp.volume(0,-200):.2e}")

    # return the total surface area of earth in m**2
    print(f"M.hyp.sa = {M.hyp.sa:.2e}")

The hypsometric data is based on the Scripps’ SRTM15+V2.5.5 grid (Tozer et al., 2019, `https://doi.org/10.1029/2019EA000658 <https://doi.org/10.1029/2019EA000658>`_), which was down-sampled to a 5-minute grid before processing the hypsometry. 

Seawater
~~~~~~~~

ESBMTK provides a :py:class:`esbmtk.seawater.SeawaterConstants()` class that will be automatically instantiated when a :py:class:`esbmtk.extended_classes.Reservoir()` instance 
definition includes the ``seawater_parameters`` keyword. This keyword expects a dictionary that specifies temperature, salinity, and pressure for a given ``Reservoirgroup``. The class methods and instance variables are accessible via the ``swc`` instance.

.. code:: ipython

    Reservoir(
        name="S_b",  # box name
        geometry=[-200, -800, 1],  # upper, lower, fraction
        concentration={M.DIC: "2220 umol/kg", M.TA: "2300 umol/kg"},
        seawater_parameters={
            "T": 25,  # Deg celsius
            "P": 0,  # Bar
            "S": 35,  # PSU
        },
        register=M,
    )
    # Acess the sewater_parameters with the swc instance
    print(f"M.S_b.density = {M.S_b.swc.density:.2e}")

Apart from density, this class will provide access to a host of instance parameters, e.g., equilibrium constants - see :py:meth:`esbmtk.seawater.SeawaterConstants.update_parameters()` for the currently defined names. Most of these values are computed by ``pyCO2SYS`` (`https://doi.org/10.5194/gmd-15-15-2022 <https://doi.org/10.5194/gmd-15-15-2022>`_). Using  ``pyCO2SYS`` provides access to a variety of parametrizations for the respective equilibrium constants, various pH scales, as well as different methods to calculate buffer factors. Unless explicitly specified in the model definition, ESBMTK uses the defaults set by pyCO2SYS. Note that when using the seawater class, the model concentration unit must be set to ``mol/kg`` as in the following example:

.. code:: ipython

    M = Model(
        stop="6 Myr",  # end time of model
        max_timestep="1 kyr",  # upper limit of time step
        element=["Carbon"],  # list of element definitions
        concentration_unit="mol/kg",
        opt_k_carbonic=13,  # Use Millero 2006
        opt_pH_scale=1,  # 1:total, 3:free scale
    )

Caveats
^^^^^^^

- Seawater Parameters are only computed once when the ``Reservoir`` is instantiated, to provide an initial steady state. Subsequent changes to seawater chemistry or physical parameters do not affect the initial state.

- The ``swc`` instance provides a ``show()`` method listing most values. However, that list may not be comprehensive.

- See the pyCO2SYS documentation for a list of parameters and options `https://pyco2sys.readthedocs.io/en/latest/ <https://pyco2sys.readthedocs.io/en/latest/>`_

- The code example ``seawater_example.py`` in the examples directory

Carbon Chemistry
~~~~~~~~~~~~~~~~

pH
^^

Unless explicitly requested (see above), pH will be reported on the total scale. The hydrogen ion concentration ([H\ :sup:`+`\]) is computed by pyCO2SYS based on the initial DIC and total alkalinity (TA) concentrations. Subsequent hydrogen concentration calculations use the iterative approach of Follows et al. 2005 (`https://doi.org/10.1016/j.ocemod.2005.05.004 <https://doi.org/10.1016/j.ocemod.2005.05.004>`_). 

Provided that the model has terms for DIC and TA, pH calculations for a given :py:class:`esbmtk.extended_classes.Reservoir()` instance are added using the :py:func:`esbmtk.carbonate_chemistry.add_carbonate_system_1()` function:

.. code:: ipython

    box_names = [A_sb, I_sb, P_sb, H_sb]  # list of Reservoir handles
    add_carbonate_system_1(box_names)

This will create Species :py:class:`esbmtk.base_classes.Species()` instances for ``Hplus`` and ``CO2aq``. After running the model, the resulting concentration data is available in the usual manner:

.. code:: ipython

    A_sb.Hplus.c
    A_sb.CO2aq.c

The remaining carbonate species are calculated during post-processing (see the :py:func:`esbmtk.post_processing.carbonate_system_1_pp()` function) and are available as

.. code:: ipython

    A_sb.pH
    A_sb.HCO3
    A_sb.CO3
    A_sb.Omega

Notes:
::::::

- The resulting concentration data depends on the choice of equilibrium constants and how they are calculated (see the ``opt_k_carbonic``, ``opt_buffers_mode`` keywords above).

- The data from post-processing is currently available as :py:class:`esbmtk.extended_classes.VectorData()` instance, rather than as :py:class:`esbmtk.base_classes.Species()` instance.

- Species that use carbonate system 2 (see below), do not need to use carbonate system 1

- ESBMTK will print a warning message of the pH changes by more than 0.01 units per time step. However, this is only a crude measure, since the solver also uses interpolation between integration steps. So this may not catch all possible scenarios.

Carbonate burial and dissolution
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Carbonate burial and dissolution use the parametrization proposed by Boudreau et al. 2010 (`https://doi.org/10.1029/2009gb003654 <https://doi.org/10.1029/2009gb003654>`_). The current ESBMTK implementation  has the following shortcomings:

- It only considers Calcium dissolution/burial (although it would be easy to add Aragonite)

- Results will only be correct as long as the depth of the saturation horizon remains below the upper depth datum of the deep-water box. Future versions will address this limitation.

The following figure provides an overview of the parametrizations and variables used by the  :py:func:`esbmtk.carbonate_chemistry.carbonate_system_2()` and :py:func:`esbmtk.carbonate_chemistry.add_carbonate_system_2()` functions.

.. _boudreau:

.. figure:: ./boudreau.png
    :width: 800


    Overview of the parametrizations and variables used by the :py:func:`esbmtk.carbonate_chemistry.carbonate_system_2()` and :py:func:`esbmtk.carbonate_chemistry.add_carbonate_system_2()` functions. Image Credit: Tina Tsan & Mahruk Niazi

Provided a given model has data for DIC & TA, and that the carbonate export flux is known, ``carbonate_system_2`` can be added to a Reservoir instance in the following way:

.. code:: ipython

    surface_boxes: tp.List = [M.L_b]
    deep_boxes: tp.List = [M.D_b]
    export_fluxes: tp.List = M.flux_summary(filter_by="PIC_DIC L_b", return_list=True)

    add_carbonate_system_2(
            this_box=deep_boxes,  # list of reservoir groups
            source_box=surface_boxes,  # list of reservoir groups
            carbonate_export_fluxes=export_fluxes,  # list of export fluxes
            z0=-200,  # depth of shelf
            alpha=alpha,  # dissolution coefficient, typically around 0.6
        )

Notes:

- boxes and fluxes are lists, since in some models there is more than one surface box (e.g., models that resolve individual ocean basins)

- ESBMTK only considers the sediment area to 6000 mbsl. The area contributed by the elevations below 6000 mbsl is negligible, and this constrain simplifies the hypsographic fit.

- The total sediment area of a given ``Reservoir`` is known provided the box-geometry was specified correctly.

- The :py:func:`esbmtk.carbonate_chemistry.carbonate_system_2()` function only returns [H\ :sup:`+`\] and the dissolution flux for the given box. It does not return the burial flux.

- Since ``carbonate_system_2`` is based heavily on the Boudreau model, it cannot currently handle carbonate chemistry dynamics for models with more than two vertical ocean boxes, e.g., it cannot be used within a model with a surface, intermediate, as well as deep box.

Please study the actual model implementations provided in the examples folder.

Post-Processing
^^^^^^^^^^^^^^^

As with ``carbonate_system_1``, the remaining carbonate species are not part of the equation system; rather, they are calculated once a solution has been found. Since the solver does not store the carbonate export fluxes, one first has to calculate the relevant fluxes from the concentration data in the model solution. This, however, is model dependent (i.e., export productivity as a function of residence time, or as a function of upwelling flux), and as such post-processing of ``carbonate_system_2``  is not done automatically, but has to be initiated manually, e.g., like this:

.. code:: ipython

    # get CaCO3_export in mol/year
    CaCO3_export = M.CaCO3_export.to(f"{M.f_unit}").magnitude
    carbonate_system_2_pp(
        M.D_b,  # Reservoir
        CaCO3_export,  # CaCO3 export flux
        200,  # z0
        6000,  # zmax
    )

This will compute all carbonate species similar to ``carbonate_system_1_pp``, and in addition calculate:

.. code:: ipython

    M.D_b.Fburial  # CaCO3 burial flux mol/year
    M.D_b.Fdiss  # CaCO3 dissolution flux mol/year
    M.D_b.zsat  # Saturation depth in mbsl
    M.D_b.zcc  # CCD depth in mbsl
    M.D_b.zsnow  # Snowline depth in mbsl

see  the :py:func:`esbmtk.post_processing.carbonate_system_2_pp()` function for details.

Carbonate System 3:
^^^^^^^^^^^^^^^^^^^

``carbonate_system_3`` currently functions almost entirely similarly to ``carbonate_system_2``, except in that it explicitly computes the "burial flux" (i.e. the carbonate flux that remains undissolved in a given box) and adds it to the reservoir box directly beneath it. 

Carbonate System 3 may be added to a model as follows:

.. code:: ipython


    add_carbonate_system_3(
            source_box=[M.S_b],  # list of reservoir groups; S_b is Surface box
            this_box=[M.D_b1],  # list of reservoir groups; D_b1 is Deep box 1
            next_box=[M.D_b2],  # list of reservoir groups; D_b2 is Deep box 2
            carbonate_export_fluxes=export_fluxes,  # list of export fluxes; declared in the same way as in CS2
            z0=-200,  # depth of shelf
            alpha=alpha,  # dissolution coefficient, typically around 0.6
        )
    f = M.flux_summary(filter_by="db2_export") #"db2_export" is the flux from D_b1 to D_b2 (i.e. "burial flux")
    M.D_b2.DIC.lif.append(f) #appends the db2_export flux object to the sink.lif list

Notes:

- At the moment, ``next_box`` must be a Reservoir class object and cannot be a Sink class object. However, one can still use this setup to pass burial flux from an ocean box to a sediment box by defining the sediment box as a Reservoir class object with seawater parameters (T, P, S) exactly equal to the ocean box just above it, and initial DIC and TA set to 0.

- As in CS2, the CS3 code adds carbonate export fluxes to ``this_box``, but relies on a ConnectionProperties instance (with the bypass "bp" keyword) to remove those same fluxes from the source box. However, there is no need to use ConnectionProperties to set up a PIC flux connection between ``this_box`` and ``next_box`` at all, as this is handled entirely by the CS3 code.

Post Processing
:::::::::::::::

CS3 post-processing functions in the same manner as CS2 post-processing. The sole difference is the name of the function, which for CS3 is ``carbonate_system_3_pp``.

Carbonate System 4:
^^^^^^^^^^^^^^^^^^^

Carbonate system 4 is an extension of ``carbonate_system_2`` and ``carbonate_system_3`` that enables carbonate chemistry calculations for models with three vertical ocean layers, i.e., models with a surface layer, an intermediate layer, and a deep layer (in addition to a sediment layer/burial box). 

The ``carbonate_system_4`` function splits Boudreau (2010)'s carbonate dissolution fluxes and adds them to either the intermediate box or the deep box depending on the relative depth of z\ :sub:`sat`\ (i.e., saturation depth) computed in each timestep. The flux-splitting scheme therefore consists of two scenarios: either z\ :sub:`sat`\ is deeper than z\ :sub:`int`\, or z\ :sub:`int`\ is deeper than z\ :sub:`sat`\. Both scenarios are visualized below:

.. _CS4 flux-splitting scheme 1:

.. figure:: ./CS4fluxsplitscheme.png
    :width: 800


    Overview of the modifications made by CS4 for the scenario where ``zsat`` is deeper than ``zint``. Image Credit: Atlas Changulani

.. _CS4 flux-splitting scheme 2:

.. figure:: ./CS4fluxsplitscheme2.png
    :width: 800


    Overview of the modifications made by CS4 for the scenario where ``zint`` is deeper than ``zsat``. Image Credit: Atlas Changulani

In the first scenario (z\ :sub:`sat`\ deeper than z\ :sub:`int`\), B\ :sub:`NS`\ (the CaCO\ :sub:`3`\ dissolution between z\ :sub:`0`\ and z\ :sub:`sat`\) is now split into two by z\ :sub:`int`\. One of these split components is added to the intermediate box, and the other to the deep box. B\ :sub:`DS`\, B\ :sub:`CC`\, and B\ :sub:`PDC`\ remain unmodified and are computed in the same manner as they are in CS2. 

In the second scenario (z\ :sub:`int`\ deeper than z\ :sub:`sat`\), the computation of B\ :sub:`NS`\ is unmodified, and the whole of it is added to the intermediate box. However, both the undersaturation and respiration components of B\ :sub:`DS`\ (dissolution of CaCO\ :sub:`3`\ raining down between z\ :sub:`sat`\ and z\ :sub:`cc`\) are split into two by z\ :sub:`int`\, and added accordingly to either the intermediate or the deep box. B\ :sub:`CC`\ and B\ :sub:`PDC`\ again remain unmodified and are computed in the same manner as they are in CS2.

Carbonate System 4 may be added to a model using the ``add_carbonate_system_4`` function as follows:

.. code:: ipython


    add_carbonate_system_4(
            source_box=[M.S_b],  # list of reservoir groups; S_b is Surface box
            this_box=[M.I_b],  # list of reservoir groups; I_b is Intermediate box 
            next_box=[M.D_b],   # list of reservoir groups; D_b is Deep box
            burial_box=[M.B_b], # list of reservoir groups; D_b is Burial box
            carbonate_export_fluxes=export_fluxes,  # list of export fluxes (from surface box); declared in the same way as in CS2
            z0=-200,  # depth of shelf
            zint=-1000, #lower depth of intermediate box
            zmax=-6000, #lower depth of deep box
            alpha=alpha,  # dissolution coefficient, typically around 0.6
        )

Notes: 

- The flux splitting scheme employed in ``carbonate_system_4`` currently assumes that the carbonate compensation depth (i.e. ``z_{cc}``) is always in the deep box. Therefore, it may not work correctly for model geometries with a very deep z\ :sub:`int`\.

- There is no need to add a ``ConnectionProperties`` instance to handle PIC flux connections between the Intermediate and Deep boxes, or the Deep and Burial boxes. This is handled entirely by CS4. However, one must still declare a ``ConnectionProperties`` instance (with the bypass "bp" keyword) to remove the total carbonate export fluxe from ``source_box``.

- At the moment, ``burial_box`` must be a Reservoir class object and cannot be a Sink class object. However, one can still use this setup to pass burial flux from an ocean box to a sediment box by defining the sediment box as a Reservoir class object with seawater parameters (T, P, S) exactly equal to the ocean box just above it, and initial DIC and TA set to 0.

Post-processing:
::::::::::::::::

Post-processing for ``carbonate_system_4`` works in a manner very similar to post-processing for ``carbonate_system_2``, and can be used to calculate carbonate species and diagnostics that are not part of the equation system after a solution has been found. 

Note, once again, that since the solver does not store the carbonate export fluxes, one first has to calculate the relevant fluxes from the concentration data in the model solution, which is model dependent (i.e., export productivity as a function of residence time, or as a function of upwelling flux). 

Note additionally that ``carbonate_system_4_pp`` only supports post-processing calculations for deep boxes. It is recommended to use ``carbonate_system_1`` for the post-processing of surface and intermediate boxes in a 3-ocean-layer model. 

Since it is necessary to separately calculate the relevant, model-specific carbonate export fluxes outside the model definition, one may include a model-specific wrapper function after the model definition in order to efficiently calculate ``carbonate_system_4`` post processing diagnostics, especially if the model contains multiple ocean basins (e.g.: separate Atlantic, Indian, and Pacific basins). An example of such a wrapper function is provided below. 

.. code:: ipython

    def cs4_pp_helper(M: Model, ocean_names: list) -> None:
        """Example wrapper function for carbonate_system_4 post-processing.

        ``carbonate_system_4_pp`` requires a CaCO3 export flux as input, and therefore 
        cannot be applied directly to a reservoir without additional calculations for 
        obtaining the export flux outside the model definition. The calculation of this 
        export flux depends entirely on the the specific model and is therefore not 
        included in ``carbonate_system_4_pp`` itself.

        This function applies carbonate_system_1_pp to surface and intermediate boxes for 
        each specified basin, calculates CaCO3 export fluxes for each basin, and then uses 
        carbonate_system_4_pp to obtain carbonate system diagnostics for the deep boxes.

        Example taken from the ESBMTK implementation of the LOSCAR model (Zeebe, 2012).

        Parameters
        ----------
        M : Model
            ESBMTK model instance.
        ocean_names : list[str]
            Ocean basin identifiers (e.g. ``["A", "I", "P"]``).

        Returns
        -------
        None
            Carbonate diagnostics are attached to the corresponding
            reservoirs as ``VectorData`` objects.

        References
        ----------
        Zeebe, R. E.: LOSCAR: Long-term Ocean-atmosphere-Sediment CArbon 
        cycle Reservoir Model v2.0.4, Geosci. Model Dev., 5, 149–166, 
        https://doi.org/10.5194/gmd-5-149-2012, 2012.

        """
        from esbmtk import carbonate_system_1_pp, carbonate_system_4_pp

        for o in ocean_names:

            # ---- Get the surface, intermediate, and deep reservoirs for each specified basin ----
            sb = eval(f"M.{o}_sb")  # surface
            ib = eval(f"M.{o}_ib")  # intermediate
            db = eval(f"M.{o}_db")  # deep

            # ---- Calculate carbonate diagnostics in surface & intermediate boxes ----
            carbonate_system_1_pp(sb)
            carbonate_system_1_pp(ib)

            # ---- MODEL-SPECIFIC EXPORT PRODUCTION CALCULATION ----
            c_name = f"Conn_{ib.name}_to_{sb.name}_PO4_mix_up"
            C: ConnectionGroup = M.connection_summary(filter_by=c_name, return_list=True)[0]
            F_PO4 = C.scale * ib.PO4.c
            ep = F_PO4 * M.PUE * M.PC_ratio * M.int_fraction / M.rain #export productivity

            #---- Apply carbonate_system_4_pp ----
            carbonate_system_4_pp(db, ep)

The function may then be called after the model run, as follows:

.. code:: ipython

    M.run()
    cs4_pp_helper(M, ["A","I","P"]) #for post-processing of Atlantic, Indian, and Pacific basins

Gas Exchange
~~~~~~~~~~~~

ESBMTK implements gas exchange across the Air-Sea interface as a :py:class:`esbmtk.connections.Species2Species()` instance, between a :py:class:`esbmtk.extended_classes.GasReservoir()` and a :py:class:`esbmtk.base_classes.Species()` instance. In the following example, we first declare a ``Gasreservoir`` and then connect it with a regular surface box. Note that the CO\ :sub:`2`\ gas transfer calculation requires that the respective surface reservoir carries the ``CO2aq`` tracer as calculated by the :py:func:`esbmtk.carbonate_chemistry_carbonate_system_1.()` function since the gas-transfer depends on the dissolved CO\ :sub:`2`\ rather than on the DIC concentration.

.. code:: ipython

    GasReservoir(
        name="CO2_At",
        species=M.CO2,
        species_ppm="280 ppm",
    )
    Species2Species(  # Example for CO2
        source=M.CO2_At,  # GasReservoir
        sink=M.L_b.DIC,  # Reservoir
        species=M.CO2,
        piston_velocity="4.8 m/d",
        ctype="gasexchange",
        id="L_b_GEX",  # connection id
    )

Defining gas transfer for O\ :sub:`2`\  uses the same approach.  Currently ESBMTK provides useful defaults for CO\ :sub:`2,`\ O\ :sub:`2`\ and N\ :sub:`2`\ only. See the isotope chapter on how to define gas exchange reactions for custom species.

Creating gas reservoirs and gas-exchange connections via Excel
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

For models with several atmospheric reservoirs and gas-exchange connections, gas reservoirs and connections can be defined using Excel worksheets, using the ``create_gas_reservoirs_from_excel`` and the ``create_gas_exchange_connections_from_excel`` functions. 

Creating gas reservoirs from Excel
::::::::::::::::::::::::::::::::::

The function ``create_gas_reservoirs_from_excel`` can be used to read gas-reservoir definitions from an Excel worksheet. Each row describes one gas reservoir. For example:

.. table::

    +-----------------+---------+----------------------+
    | name            | species | species\ :sub:`ppm`\ |
    +-----------------+---------+----------------------+
    | CO2\ :sub:`At`\ | CO2     | 280 ppm              |
    +-----------------+---------+----------------------+
    | O2\ :sub:`At`\  | O2      | 21 percent           |
    +-----------------+---------+----------------------+

The species concentrations can be specified in terms of ppm or percentage, as demonstrated above. Note that numeric values supplied in the ``species_ppm`` column with no specified units are automatically interpreted as ppm.

The function can be called as follows:

.. code:: ipython

    create_gas_reservoirs_from_excel(
            M, #Model object
            "LOSCAR_sheets.xlsx", #specify file path
            sheet_name="gas_reservoirs" #specify worksheet (default = "gas_reservoirs")
        )

Creating gas exchange connections from Excel
::::::::::::::::::::::::::::::::::::::::::::

The function ``create_gas_exchange_connections_from_excel`` can be used to read gas-exchange connection definitions from an Excel worksheet. Each row describes the gas exchange connections for one gaseous species.

.. table::

    +---------+------------------------------------------------------------+--------------------------+
    | species | basins                                                     | piston\ :sub:`velocity`\ |
    +---------+------------------------------------------------------------+--------------------------+
    | CO2     | A\ :sub:`sb`\, I\ :sub:`sb`\, P\ :sub:`sb`\, H\ :sub:`sb`\ | 4.8 m/d                  |
    +---------+------------------------------------------------------------+--------------------------+
    | O2      | A\ :sub:`sb`\, I\ :sub:`sb`\, P\ :sub:`sb`\, H\ :sub:`sb`\ | 4.8 m/d                  |
    +---------+------------------------------------------------------------+--------------------------+

The function can be called as follows:

.. code:: ipython

    create_gas_exchange_connections_from_excel(
        M, #Model object
        "LOSCAR_sheets.xlsx", #specify file path
        sheet_name="gas_exchange" #specify worksheet (default = "gas_exchange")
    )

Note that since gas exchange connections require the initialization of Carbonate System 1 to work, the function ``create_gas_exchange_connections_from_excel`` must be placed after ``add_carbonate_system_1`` in the model definition.

pCO\ :sub:`2`\ Dependent Weathering
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

ESBMTK defines a simple power law function to calculate pCO\ :sub:`2`\ dependent weathering fluxes (see e.g., Walker and Hays, 1981, `https://doi.org/10.1029/jc086ic10p09776 <https://doi.org/10.1029/jc086ic10p09776>`_):


.. math::

    f =  A \times  f_{0} \times  \left(\frac{pCO_{2}}{p_{0}CO_{2}}\right)^{c}


where :math:`A` denotes the area, :math:`f_0` the weathering flux at :math:`p_{0}CO_2`, pCO\ :sub:`2`\ the CO\ :sub:`2`\ partial pressure at a given time :math:`t`, :math:`p_{0}CO_2` the reference partial pressure of CO\ :sub:`2`\ and :math:`c` a constant.  See the :py:func:`esbmtk.processes.weathering()` function for details. Within the context of ESBMTK, weathering fluxes are just another connection type:

.. code:: ipython

    Species2Species(  # CaCO3 weathering
        source=M.Fw.DIC,  # source of flux
        sink=M.L_b.DIC,
        reservoir_ref=M.CO2_At,  # pCO2
        scale=1,  # optional, defaults to 1
        ex=0.2,  # exponent c
        pco2_0="280 ppm",  # reference pCO2
        rate="12 Tmol/a",  # rate at pco2_0
        ctype="weathering",
        id="wca",
    )
