

Adding Complexity
-----------------

Working with multiple species
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The basic building blocks introduced so far are sufficient to create a single-species model. Adding further species is straightforward. The primary
difference is that reservoirs, sources, sinks, and connections must now specify which species they contain or transport.

In the example below, we extend the previous simple P-cycle model into a multispecies model by expressing phosphorus cycling as a function of organic matter (OM) production and remineralization. Organic matter production is represented using a fixed C:P Redfield ratio so that carbon export is linked directly to phosphorus uptake.

The complete example is available as ``po4_3.py`` in the ESBMTK-Examples repository.

Defining the Model instance
^^^^^^^^^^^^^^^^^^^^^^^^^^^

We begin by defining the model instance and register the required species definitions. Multiple species can be registered in the model by simply extending the list of elements, as shown below:

.. code:: ipython
    :name: po43_1

    from esbmtk import (
        Model,
        Reservoir,  # the reservoir class
        ConnectionProperties,  # the connection class
        SourceProperties,  # the source class
        SinkProperties,  # sink class
        data_summaries,
        Q_,
    )

    M = Model(
        stop="6 Myr",  # end time of model
        max_timestep="1 kyr",  # upper limit of time step
        element=["Phosphor", "Carbon"],  # list of species definitions
    )

    # boundary conditions
    F_w_PO4 =  M.set_flux("45 Gmol", "year", M.PO4) # P @280 ppm (Filipelli 2002)
    tau = Q_("100 year")  # PO4 residence time in surface boxq
    F_b = 0.01  # About 1% of the exported P is buried in the deep ocean
    thc = "20*Sv"  # Thermohaline circulation in Sverdrup
    Redfield = 106 # C:P

Similarly, multiple species can be registered with the source, sink, and reservoir objects, by extending the lists and dictionaries associated with species or concentrations keywords. 

.. code:: ipython
    :name: po43_2

    SourceProperties(
        name="weathering",
        species=[M.PO4, M.DIC], #multi-species syntax
    )
    SinkProperties(
        name="burial",
        species=[M.PO4, M.DIC], #multi-species syntax
    )
    Reservoir(
        name="S_b",
        volume="3E16 m**3",  # surface box volume
        concentration={M.DIC: "0 umol/kg", M.PO4: "0 umol/kg"}, #multi-species syntax
    )
    Reservoir(
        name="D_b",
        volume="100E16 m**3",  # deep box volume
        concentration={M.DIC: "0 umol/kg", M.PO4: "0 umol/kg"}, #multi-species syntax
    )

Transporting Multiple Species
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Connections created between reservoir groups using ``ConnectionProperties`` automatically apply to every species contained within those groups unless an explicit species list is supplied.

For example, thermohaline circulation can be applied simultaneously to both DIC and PO4 by connecting the reservoir groups via ``ConnectionProperties``.

.. code:: ipython
    :name: po43_3

    ConnectionProperties(  # thermohaline downwelling
        source=M.S_b,  # source of flux
        sink=M.D_b,  # target of flux
        ctype="scale_with_concentration",
        scale=thc,
        id="thc_up",
    )
    ConnectionProperties(  # thermohaline upwelling
        source=M.D_b,  # source of flux
        sink=M.S_b,  # target of flux
        ctype="scale_with_concentration",
        scale=thc,
        id="thc_down",
    )

If different species require different transport rates, the ``rate`` (or ``scale``) keyword can instead be provided as a dictionary.

For example,

.. code:: ipython
    :name: po43_4

    ConnectionProperties(
        source=M.weathering,  # source of flux
        sink=M.S_b,  # target of flux
        rate={M.DIC: F_w_PO4 * Redfield, M.PO4: F_w_PO4},  # rate of flux
        ctype="regular",
        id="weathering",  # connection id
    )

Connections may also use one species to determine the transport rate of another. This is done using the ``ref_reservoirs`` or ``ref_flux`` keywords.

For example, the code below links organic carbon production to phosphate uptake using a fixed Redfield ratio.

.. code:: ipython
    :name: po43_5

    # P-uptake by photosynthesis
    ConnectionProperties(  #
        source=M.S_b,  # source of flux
        sink=M.D_b,  # target of flux
        ctype="scale_with_concentration",
        scale=M.S_b.volume / tau,
        id="primary_production",
        species=[M.PO4],  # apply this only to PO4
    )
    # OM Primary production as a function of P-concentration
    ConnectionProperties(  #
        source=M.S_b,  # source of flux
        sink=M.D_b,  # target of flux
        ref_reservoirs=M.S_b.PO4,
        ctype="scale_with_concentration",
        scale=Redfield * M.S_b.volume / tau,
        species=[M.DIC],
        id="OM_production",
    )
    # P burial 
    ConnectionProperties(  #
        source=M.D_b,  # source of flux
        sink=M.burial,  # target of flux
        ctype="scale_with_flux",
        ref_flux=M.flux_summary(filter_by="primary_production",return_list=True)[0],
        scale={M.PO4: F_b, M.DIC: F_b * Redfield},
        id="burial",
    )

One can now proceed to define the particulate phosphate transport as a function of organic matter export

.. code:: ipython

    M.run()
    pl = data_summaries(
        M,  # model instance 
        [M.DIC, M.PO4],  # SpeciesProperties list 
        [M.S_b, M.D_b],  # Reservoir list
    )
    M.plot(pl, fn="po4_3.png")

which results in the below plot. The full code is available in the examples directory as ``po4_2.py``

.. _po4_2:

.. figure:: ./po4_3.png
    :width: 400


    Output of ``po4_3.py`` demonstrating the use of the ``data_summaries()`` function

Using many boxes
~~~~~~~~~~~~~~~~

The ESBMTK classes introduced thus far are sufficient to build complex models. As models grow larger, however, defining every reservoir and connection individually becomes repetitive. A helpful approach is therefore to use Python dictionaries together with a set of utility functions that simplify the creation of reservoirs and connections.

These helper functions are included with ESBMTK; however, they are not part of the core API and are therefore less extensively documented and tested. It may be useful to refer to the ``Boudreau2010.py`` example in the ESBMTK examples repository to understand their use in a complete model.

For these functions to operate correctly, reservoir names should follow the convention ``area_depth``. For example, ``L_sb`` may represent a low-latitude surface box, while ``A_db`` may represent an Atlantic deep-ocean box. The specific names are arbitrary, but the underscore is used to separate the horizontal region (e.g., Atlantic, Pacific, low latitude, high latitude) from the vertical layer (e.g., surface, intermediate, deep).

The following code examples demonstrate how to create multiple boxes simultaneously by first defining a dictionary containing the box geometry and initial values, followed by the :py:class:`esbmtk.utility_functions.initialize_reservoirs()` function to instantiate the corresponding ``Reservoir`` objects. 

The ``Boudreau2010.py`` example available at `https://github.com/uliw/ESBMTK-Examples <https://github.com/uliw/ESBMTK-Examples>`_ illustrates a practical application of this approach.

.. code:: ipython

    box_parameters: dict = {  # name: [[geometry], T, P]
        "H_b": {  # High-Lat Box
            "c": {
                M.DIC: "2153 umol/kg",
                M.TA: "2345 umol/kg",
                M.PO4: "1.5 umol/kg",
                M.O2: "200 umol/kg",
            },
            "g": {"area": "0.5e14m**2", "volume": "1.76e16 m**3"},  # geometry
            #Note: geometry can also be defined in terms of [z_top, z_bottom, area_percentage]
            "T": 2,  # temperature in C
            "P": 17.6,  # pressure in bar
            "S": 35,  # salinity in psu
        },
        "L_b": {  # Low-Lat Box
            "c": {
                M.DIC: "1952 umol/kg",
                M.TA: "2288 umol/kg",
                M.PO4: "1.5 umol/kg",
                M.O2: "200 umol/kg",
            },
            "g": {"area": "2.85e14m**2", "volume": "2.85e16 m**3"},
            "T": 21.5,
            "P": 5,
            "S": 35,
        },
    # Instantiate Reservoir objects        
    species_list = initialize_reservoirs(M, box_parameters)

Transport connections can be defined in a similar manner. Each dictionary key must follow the convention ``source_to_target@id``, where ``id`` identifies the transport process in the same way as the ``id`` argument of the ``Species2Species`` and ``ConnectionProperties`` classes. 

Therefore, to specify, e.g., thermohaline upwelling from the Atlantic deep box  to the Atlantic intermediate box, one would use ``A_db_to_A_ib@thc``  as the dictionary key. 

The following examples define the thermohaline transport in a LOSCAR-type model (based on `Zeebe, 2012 <https://gmd.copernicus.org/articles/5/149/2012/>`_):

.. code:: ipython

    # Conveyor belt
    thc = Q_("20*Sv")
    ta = 0.2  # upwelling coefficient Atlantic ocean
    ti = 0.2  # upwelling coefficient Indian ocean

    # Specify the mixing and upwelling terms as dictionary
    connection_dict = {
            # source_to_sink@id
            # thermohaline, upwelling, and advection
            "H_b_to_A_db@thermohaline": {
                "ty": "scale_with_concentration",
                "sc": thc,
                "sp": species_list,
            },
            "A_ib_to_H_b@thermohaline": {
                "ty": "scale_with_concentration",
                "sc": thc,
                "sp": species_list,
            },
            "A_db_to_A_ib@upwelling": {
                "ty": "scale_with_concentration",
                "sc": ta * thc,
                "sp": species_list,
            },
            "I_db_to_I_ib@upwelling": {
                "ty": "scale_with_concentration",
                "sc": ti * thc,
                "sp": species_list,
            },
            "A_db_to_I_db@thermohaline": {
                "ty": "scale_with_concentration",
                "sc": (1 - ta) * thc,
                "sp": species_list,
            },
            "I_db_to_P_db@thermohaline": {
                "ty": "scale_with_concentration",
                "sc": (1 - ta - ti) * thc,
                "sp": species_list,
            },
            "P_db_to_P_ib@thermohaline": {
                "ty": "scale_with_concentration",
                "sc": (1 - ta - ti) * thc,
                "sp": species_list,
            },
            "P_ib_to_I_ib@thermohaline": {
                "ty": "scale_with_concentration",
                "sc": (1 - ta - ti) * thc,
                "sp": species_list,
            },
            "I_ib_to_A_ib@thermohaline": {
                "ty": "scale_with_concentration",
                "sc": (1 - ta) * thc,
                "sp": species_list,
            },
        }
        create_bulk_connections(connection_dict, M)

Where ``connection_dict`` is a dictionary describing the connection names (in the format of ``source_to_sink@id``), types, scale, and species; whereas the ``create_bulk_connections()`` function is used to instantiate the necessary connections.

The previous example applies the same transport rules to every species. More complex connection dictionaries can also be created explicitly. 

In the following example, primary production is defined as a function of phosphate upwelling. Here, we first obtain the relevant upwelling fluxes using ``M.flux_summary()``, which are then used as reference fluxes when defining the particulate organic phosphate (POP) export in the ``connection_dictionary`` definition.

This example can be found in ``LOSCAR_modern_example.py`` within the `ESBMTK Examples repository <https://github.com/uliw/ESBMTK-Examples/tree/staging/LOSCAR_2012>`_.

.. code:: ipython

    M.PUE = 0.8 #Phosphorus Uptake Efficiency
    M.ib_remin = 0.78 #Phosphate remineralization coefficient intermediate box 
    M.db_remin = 1 - M.ib_remin #Phosphate remineralization coefficient deep box

    # Get all upwelling phosphate fluxes except the high-latitude box
    pfluxes = M.flux_summary(filter_by="PO4_mix_up", exclude="H_", return_list=True)

    # Export productivity in the high latitude box is fixed (Zeebe, 2012)
    pp_hl = Q_(f"{1.8 * M.H_sb.area.magnitude / M.PC_ratio} mol/a")

    ct = {  # Surface box to intermediate box (sb to ib)
            (
                "A_sb_to_A_ib@A_sb_2_A_ib_POP_ex",
                "I_sb_to_I_ib@I_sb_2_I_ib_POP_ex",
                "P_sb_to_P_ib@P_sb_2_P_ib_POP_ex",
            ): {
                "ty": "scale_with_flux",
                "sc": M.PUE * M.ib_remin, #scale 
                "re": pfluxes, #reference flux
                "sp": M.PO4,
            },
            # surface box to deep box (sb to db)
            (
                "A_sb_to_A_db@A_sb_2_A_db_POP_ex",
                "I_sb_to_I_db@I_sb_2_I_db_POP_ex",
                "P_sb_to_P_db@P_sb_2_P_db_POP_ex",
            ): {
                "ty": "scale_with_flux",
                "sc": M.PUE * M.db_remin,
                "re": pfluxes,
                "sp": M.PO4,
            },
            # high latitude box to deep ocean boxes (H_sb to db)
            (
                "H_sb_to_A_db@H_sb_2_A_db_POP_ex",
                "H_sb_to_I_db@H_sb_2_I_db_POP_ex",
                "H_sb_to_P_db@H_sb_2_P_db_POP_ex",
            ): {
                # here we use a fixed rate following Zeebe's LOSCAR model
                "ra": [
                    pp_hl * 0.3,
                    pp_hl * 0.3,
                    pp_hl * 0.4,
                ],
                "sp": M.PO4,
                "ty": "Regular",
            },
    }
    create_bulk_connections(ct, M)

You can also use the ``create_connections_from_flux_list`` function to create a set of :py:class:`esbmtk.connections.Species2Species` connections based on an existing list of flux objects. This is particularly useful when multiple species are transported along the same pathway and their fluxes can be expressed as a scaled version of an already existing flux.

For each reference flux in the provided list, the function identifies the source and sink reservoirs from the flux naming convention and creates a new connection between the corresponding species reservoirs for the given species. The new connection uses the original flux as a reference flux and applies a user-provided scaling factor. An example is given below:

.. code:: ipython

    pfluxes = M.flux_summary(filter_by="POP_ex", return_list=True) #flux list of POP export fluxes

        # Particulate OM DIC
        create_connections_from_flux_list(
            M,  # model
            pfluxes,  # flux list
            "POM_DIC",  # new ID
            M.DIC,  # species
            M.PC_ratio,  # scale
        )

This creates a set of new DIC connections following the same pathways as the POP export fluxes, scaled by the phosphorus-to-carbon ratio.

Using Excel sheets for model definitions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

For models with many reservoirs and transport connections, creating reservoir and connections using python dictionaries can become repetitive and difficult to maintain. ESBMTK therefore provides helper functions that read reservoir and transport matrix definitions directly from Excel workbooks. These helper functions include:

- ``create_reservoirs_from_excel``

- ``create_transport_matrix_from_excel``

- ``create_gas_reservoirs_from_excel``

- ``create_gas_exchange_connections_from_excel``

Which can be used to initialize ocean reservoirs, transport matrix, atmospheric reservoirs, and air-sea gas-exchange connections respectively using an excel sheet (.xlsx or .odf). 

The functions ``create_reservoirs_from_excel`` and ``create_transport_matrix_from_excel`` are described in further detail below. 

For more information on ``create_gas_reservoirs_from_excel`` and ``create_gas_exchange_connections_from_excel``, please see the manual's section on `gas exchange <https://esbmtk.readthedocs.io/en/latest/manual/manual-4.html#gas-exchange>`_.

Notes:

- Column names must *exactly* match the expected names described below.

- Reservoir names used in the worksheets must match those used in the model.

- Any variables specified herein must also be defined in the python model file.

- Numerical values may be entered directly or calculated using standard Excel formulas.

Creating reservoirs from Excel
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

The function ``create_reservoirs_from_excel`` creates ocean reservoirs, sources, and sinks from information provided in an Excel file. 

Each row in the excel table represents one reservoir definition. Reservoir geometry, temperature, pressure, and salinity, initial species concentrations, and initial isotope compositions can be specified as columns, as shown in the example table below:

.. table::

    +---------------+-----------+----------------+-------------------+--------------------------+-------------+----------+----------+------+--------------------+
    | name          | type      | z\ :sub:`top`\ | z\ :sub:`bottom`\ | area\ :sub:`percentage`\ | temperature | pressure | salinity |  DIC | delta\ :sub:`DIC`\ |
    +===============+===========+================+===================+==========================+=============+==========+==========+======+====================+
    | A\ :sub:`sb`\ | reservoir |              0 |              -100 |                     0.26 |          20 |        5 |     34.7 | 2210 |                  2 |
    +---------------+-----------+----------------+-------------------+--------------------------+-------------+----------+----------+------+--------------------+
    | A\ :sub:`ib`\ | reservoir |           -100 |             -1000 |                     0.26 |          10 |      100 |     34.7 | 2210 |                  2 |
    +---------------+-----------+----------------+-------------------+--------------------------+-------------+----------+----------+------+--------------------+
    | A\ :sub:`db`\ | reservoir |          -1000 |             -6000 |                     0.26 |           2 |      240 |     34.7 | 2210 |                  2 |
    +---------------+-----------+----------------+-------------------+--------------------------+-------------+----------+----------+------+--------------------+
    | Fw            | source    | \              | \                 | \                        | \           | \        | \        | \    | \                  |
    +---------------+-----------+----------------+-------------------+--------------------------+-------------+----------+----------+------+--------------------+
    | Fb            | sink      | \              | \                 | \                        | \           | \        | \        | \    | \                  |
    +---------------+-----------+----------------+-------------------+--------------------------+-------------+----------+----------+------+--------------------+

Ocean reservoir rows necessarily require the ``name``, ``type``, and geometry columns (``z_top``, ``z_bottom``, and ``area_percentage``), whereas only the ``name`` and ``type`` columns are necessary for the source and sink reservoirs. Default temperature, pressure, and salinity values can be specified as a function parameter.

Isotope compositions can optionally be specified using columns named ``delta_[species]``. For example, the column ``delta_DIC`` specifies the initial :math:`\delta`\ :sup:`13`\C isotopic composition of any given reservoir. Note that isotopes are not initialized for reservoirs for which the isotope column is left blank (e.g., ``Fw`` and ``Fb`` in the table above).

Important: at present, isotopes must be initialized separately for the Source and Sink. This can be done as shown in the function call example below.

The function can be called as follows:

.. code:: ipython


    #----- Isotope ratios ----- #
    M.Fw_DIC_d = 1.5  # Carbonate weathering delta
    M.Fb_DIC_d = 0 # burial delta (included for isotope initialization in Sink) 

    #---- Create reservoirs from excel ----#
    species_list = create_reservoirs_from_excel(
            M, #Model object
            "LOSCAR_sheets.xlsx", #specify Excel file name / file path
            sheet_name="reservoirs" #specify Excel worksheet (default = "reservoirs")
            )

    #---- Separately initialize reservoirs for Source and Sink ----#
    M.Fw.DIC.delta = M.Fw_DIC_d #initialize delta for Source object
    M.Fb.DIC.delta = M.Fb_DIC_d #initialize delta for Sink object

Notes:

- The function only accepts reservoir geometry information provided via the ``z_top``, ``z_bottom``, and ``area_percentage`` parameters at present.

- Species columns are detected automatically from species registered in the model.

- Species concentrations are assumed to be in umol/kg, unless otherwise specified.

- Only isotope columns corresponding to species registered in the model are permitted; otherwise an error is raised.

Creating transport matrices from Excel
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

The function ``create_transport_matrix_from_excel`` creates mixing and thermohaline transport connections between reservoirs via a worksheet. Each row defines a single connection. 

Required excel columns:

- ``source``

- ``sink``

- ``flux_id``

- ``sc``

Example rows and columns may look like the following:

.. table::

    +---------------+---------------+------------------+-------------+
    | source        | sink          | flux\ :sub:`id`\ | sc          |
    +---------------+---------------+------------------+-------------+
    | H\ :sub:`sb`\ | A\ :sub:`db`\ | thermohaline     | thc         |
    +---------------+---------------+------------------+-------------+
    | A\ :sub:`ib`\ | A\ :sub:`sb`\ | mix\ :sub:`up`\  | 21 Sverdrup |
    +---------------+---------------+------------------+-------------+

The scaling factor ``sc`` may be specified in Sverdrups (e.g., “10 Sverdrup”) or as a variable defined within the python file (e.g., ``thc``).

Note: mixing fluxes are symmetric, so for each mix\ :sub:`up`\ flux, a corresponding “mix\ :sub:`down`\” flux does not need to be specified and will be created automatically. 

The function can be called as follows:

.. code:: ipython

    create_transport_matrix_from_excel(
            M, #Model object
            "LOSCAR_sheets.xlsx", #specify file path
            species_list, #list of species being transported via advection and mixing
            sheet_name="transport_matrix" #specify worksheet (default = "transport_matrix")
            )

It is recommended to check out the ``LOSCAR_2012`` directory in `ESBMTK-Examples <https://github.com/uliw/ESBMTK-Examples/tree/main>`_ for a detailed example of the functions described above.

Model forcing
~~~~~~~~~~~~~

ESBMTK implements model forcing through the :py:class:`esbmtk.extended_classes.Signal()` class. A signal represents a time-dependent change in a model parameter or flux and can be attached to a :py:class:`esbmtk.connections.Species2Species()` instance that will then act on the associated connection.

This class provides the following ways to create a signal:

- Pre-defined functions, e.g., ``square()``, ``pyramid()``, or ``bell()``. These are defined by specifying the signal start time (relative to the model time), signal duration, and signal size or magnitude.

- External data via ``filename()``. This keyword is a string pointing to a CSV file that specifies the following columns: ``Time [yr]``, ``Rate/Scale [units]``, ``delta value [dimensionless]`` The class will attempt to convert the data into the correct model units. This process is not, however, very robust.

The default is to add the signal to a given connection. It is however also possible to use the signal data as a scaling factor. Signals are cumulative, i.e., complex signals are created by adding one signal to another (i.e., S\ :sub:`new`\ = S1 + S2). Using the P-cycle model from the previous chapter (see ``po4_1.py``) we can add a signal by first defining a signal instance, and then associating the instance with a weathering connection instance (this model is available as ``po4_2.p4`` see `https://github.com/uliw/ESBMTK-Examples <https://github.com/uliw/ESBMTK-Examples>`_)

.. code:: ipython
    :name: po42_2

    from esbmtk import Signal

    Signal(
        name="CR",  # Signal name
        species=M.PO4,  # SpeciesProperties
        start="1 Myrs",
        shape="pyramid",
        duration="1 Myrs",
        mass="45 Pmol",
    )

    ConnectionProperties(
        source=M.weathering,  # source of flux
        sink=M.S_b,  # target of flux
        rate=F_w,  # rate of flux
        id="river",  # connection id
        signal=M.CR,
        species=[M.PO4],
        ctype="regular",
    )
    M.run()

Note that the ``plot()`` method accepts the signal object as well. In general, any ESBMTK object that has data that varies with time, can be plotted by the ``plot()`` method. ESBMTK also provides classes to include external data  :py:class:`esbmtk.extended_classes.ExternalData()`  as well as classes to mix and match data into the same plot :py:class:`esbmtk.extended_classes.DataField()`. 

The file ``is92a_comparison_plots.py`` (see  `https://github.com/uliw/ESBMTK-Examples/tree/main/Boudreau/2010 <https://github.com/uliw/ESBMTK-Examples/tree/main/Boudreau/2010>`_) shows a use case. 

Furthermore, :py:class:`esbmtk.model.Model.plot()`  returns a tuple with the figure instance, list of ``axs`` objects, which allows even more complex figure manipulations (see ``steady_state_plots.py`` in the same repository).

.. code:: ipython

    M.plot([M.S_b.PO4, M.D_b.PO4, M.CR], fn="po4_2.png")
    #  M.save_data()

This will result in the following output:

.. _sig:

.. figure:: ./po4_2.png
    :width: 400


    Example output for the ``CR`` signal above. See ``po4_2.py`` in the examples directory.

Signal data structure
^^^^^^^^^^^^^^^^^^^^^

The original signal data (as read from a csv etc.) is available through the ``.s_time``, ``.s_data`` instance variables. The padded/cropped data that is interpolated for each time point, is stored in the ``.cd_m`` (and ``.cd_l`` if isotope data is present) instance variables.The sub-sampled signal data that is used for plotting is stored in ``.m``, ``.l`` and ``.d`` respectively.  Signal data can also be queried interactively by calling the signal with a given time values, e.g., ``M.PO4_signal(12)``. 

Applying a signal to multiple connections
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Adding signals is a computationally expensive process due to the involvement of multiple function calls. When the same signal shape is used to modify multiple connections, it is more efficient to create a placeholder connection with the signal and then use a ``scale_with_flux`` connection type to reference the placeholder flux. This approach has the added advantage that each ``scale_with_flux`` connection can set its own scaling factor.

.. code:: ipython

    # read the forcing (signal) data
    M.PW_SO4_Koelling = Signal(
        name="PW_SO4_Koelling",
        species=M.SO4,
        filename="koelling_pyrite_data_3Ma_w_isotopes.csv",
        stype="addition",
        register=M,
    )

    # Create a placeholder flux that does not affect the model 
    # and connect the signal data 
    Species2Species(
        ctype="regular",
        source=M.Fw.SO4,
        sink=M.Fb.SO4,
        signal=M.PW_SO4_Koelling,
        id="signal_as_flux",
    )

    Species2Species(
        ctype="scale_with_flux",
        id="actual_flux",
        source=M.Fw.SO4,
        sink=M.L_b.SO4,
        ref_flux="signal_as_flux",
        scale=3, 
    )

Signals and isotopes
^^^^^^^^^^^^^^^^^^^^

Signal data can be applied to isotope effects as well. For this you need to specify a second column in the signal data file that contains delta values with a header like this ``d34S [dimensionless]``. The data is interpreted according to the connection setting. I.e., if the connection specifies a delta-value, the third column will be interpreted as delta value (ditto for epsilon values).

Isotope effects are always additive. I.e., If there is a flux A, and a signal B, ESBMTK will calculate the isotope effects for A according to the delta/epsilon value that is set in the connection properties, and the calculate the isotope effects for the  signal flux based on the values delta/epsilon values in the signal data file.
